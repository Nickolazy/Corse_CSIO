<template>
  <button class="news-shares-left-button" type="button">
    <svg viewBox="0 0 11 19" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 18L2 9.5L10 1" stroke="#430B51" stroke-width="2"/>
    </svg>
  </button>
</template>

<script setup>

</script>

<style scoped>

</style>
