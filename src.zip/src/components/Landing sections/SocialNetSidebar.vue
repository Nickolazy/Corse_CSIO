<template>
  <div class="social-networks">
    <ul class="social-networks-list">
      <li class="social-networks-item">
        <a href="https://vk.com/csio_dpo" class="social-networks-link" target="_blank">
          <img
            src="../../assets/img/social-networks/vk-logo-icon.svg"
            alt="VK"
            class="social-networks-link-image"
            width="40"
            height="40"
            loading="lazy">
        </a>
      </li>

      <li class="social-networks-item">
        <a href="https://t.me/csiodpo" class="social-networks-link" target="_blank">
          <img
            src="../../assets/img/social-networks/telegram-logo-icon.svg"
            alt="Telegram"
            class="social-networks-link-image"
            width="40"
            height="40"
            loading="lazy">
        </a>
      </li>

      <li class="social-networks-item">
        <a href="https://ok.ru/group/70000006090207" class="social-networks-link" target="_blank">
          <img
            src="../../assets/img/social-networks/ok-logo-icon.svg"
            alt="OK"
            class="social-networks-link-image"
            width="40"
            height="40"
            loading="lazy">
        </a>
      </li>

      <li class="social-networks-item">
        <a href="https://my.mail.ru/community/csio_dpo/" class="social-networks-link" target="_blank">
          <img
            src="../../assets/img/social-networks/mail-ru-logo-icon.svg"
            alt="Mail.ru"
            class="social-networks-link-image"
            width="40"
            height="40"
            loading="lazy">
        </a>
      </li>
    </ul>
  </div>
</template>

<script setup>
  
</script>

<style scoped>

</style>