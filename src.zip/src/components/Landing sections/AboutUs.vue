<template>
  <div class="section about-us">
    <div class="container">
      <h2 class="heading-one about-us-title">
        О нас
      </h2>
      <div class="about-us-subtitle">
        <p>
          Наш учебный центр – Ваш надежный<br/>
                          партнёр в обучении с 2008 года
        </p>
      </div>

      <ul class="about-us-list">
        <li class="about-us-item">
          <div class="about-us-item-block">
            <p>
              В первые годы работы мы зарекомендовали себя с хорошей стороны, 
              как в плане обучения руководителей, специалистов и обслуживающего персонала, 
              так и в части оформления необходимых документов и исполнения всех договорных 
              обязательств в срок. 
            </p>
          </div>
        </li>

        <li class="about-us-item about-us-item-right">
          <div class="about-us-item-block">
            <p>
              Таким образом руководству предприятия удалось расширить список клиентов, 
              что дало толчок для дальнейшего развития.  
            </p>
          </div>
        </li>

        <li class="about-us-item">
          <div class="about-us-item-block">
            <p>
              Для осуществления качественного процесса обучения подобран
              высококвалифицированный преподавательский состав, 
              который обеспечивает грамотный и осмысленный подход к каждому вопросу. 
            </p>
          </div>
        </li>
      </ul>
    </div>
  </div>
  
</template>

<script setup>
  
</script>

<!-- <style scoped>

</style> -->