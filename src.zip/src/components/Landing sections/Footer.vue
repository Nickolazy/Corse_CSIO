<template>
  <div class="footer">
    <div class="container-header">
      <div class="footer-info-wrapper">
        <div class="footer-info-location">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M21 10C21 17 12 23 12 23C12 23 3 17 3 10C3 5.02944 7.02944 1 12 1C16.9706 1 21 5.02944 21 10V10Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M12 13C13.6569 13 15 11.6569 15 10C15 8.34315 13.6569 7 12 7C10.3431 7 9 8.34315 9 10C9 11.6569 10.3431 13 12 13Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <address>
            Люблинская д 76 к 2 пом 11Н
          </address>
        </div>

        <div class="footer-info-mail">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M22 6L12 13L2 6" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <a href="mailto:info@csio-dpo.ru" class="footer-info-mail-link">info@csio-dpo.ru</a>
        </div>

        <div class="footer-info-phone">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.9999 16.92V19.92C21.0022 20.4831 20.767 21.0211 20.352 21.4018C19.937 21.7825 19.3808 21.9707 18.8199 21.92C15.7428 21.5856 12.7869 20.5341 10.1899 18.85C7.77377 17.3146 5.72528 15.2661 4.18994 12.85C2.49992 10.2412 1.44818 7.27097 1.11994 4.17998C1.06941 3.62085 1.25621 3.06623 1.63471 2.6516C2.0132 2.23697 2.54853 2.0005 3.10994 1.99998H6.10994C7.1138 1.9901 7.96944 2.72594 8.10994 3.71998C8.23656 4.68004 8.47139 5.6227 8.80994 6.52998C9.08468 7.26085 8.90896 8.08478 8.35994 8.63998L7.08994 9.90998C8.5135 12.4135 10.5864 14.4864 13.0899 15.91L14.3599 14.64C14.9151 14.091 15.7391 13.9152 16.4699 14.19C17.3772 14.5285 18.3199 14.7634 19.2799 14.89C20.2855 15.0318 21.0251 15.9048 20.9999 16.92Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          <a href="tel:+74951976565" class="footer-info-phone-number">+7 (495) 197-6565</a>
        </div>
      </div>

      <div class="footer-copyright">
        <p>© 2023 АНО ДПО "ЦСИО"</p>
      </div>
    </div>
  </div>
</template>

<script setup>
  
</script>

<style scoped>

</style>